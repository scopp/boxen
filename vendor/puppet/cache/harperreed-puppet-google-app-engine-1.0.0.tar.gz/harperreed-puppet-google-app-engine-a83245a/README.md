# google-app-engine Puppet Module for Boxen

Requires the following boxen modules:

## Usage

```puppet
include google-app-engine
```

## Required Puppet Modules

* boxen
* homebrew

