# Groovy Puppet Module for Boxen

Install [Groovy](http://groovy.codehaus.org/)

## Usage

```puppet
include groovy
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
